
#include "NullTypeAttributeAdapterFactory.hpp"

GSAPI::NullTypeAttributeAdapterFactory::~NullTypeAttributeAdapterFactory ()
{}
