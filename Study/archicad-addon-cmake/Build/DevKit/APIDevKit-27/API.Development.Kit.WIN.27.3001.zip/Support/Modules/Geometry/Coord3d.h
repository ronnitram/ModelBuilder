// *********************************************************************************************************************
// Description:		Point3D, Vector3D template based definitions
//
// Module:			Geometry
// Namespace:		Geometry
// Contact person:	FGY
//
// *********************************************************************************************************************

#ifndef COORD3D_H
#define COORD3D_H

#pragma once

#include "Vector3D.hpp"
#endif

